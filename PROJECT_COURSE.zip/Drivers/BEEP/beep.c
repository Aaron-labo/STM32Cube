/*
 * beep.c
 *
 *  Created on: Apr 3, 2021
 *      Author: Francis
 */

#include "beep.h"
